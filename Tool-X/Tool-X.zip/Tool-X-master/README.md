
# What is Tool-X ?

Tool-X is a kali linux hacking Tool installer. Tool-X is Developed By Rajkumar Dusad. with the help of Tool-X you can install best hacking tools in Rooted or Non Rooted Android devices. In the Tool-X there are almost 110 hacking tools available for termux app and GNURoot Debian terminal. you can install any tool by single click. Tool-X is Specially made for Termux and GNURoot Debian Terminal. Now Tool-X is available for Ubuntu.
<br/><br/><br/>

# Features

Install any tools by single click. You can install almost 110 tools in termux and GNURoot Debian Terminal.
<br/></br>

<p align="center">
<img src="https://github.com/Rajkumrdusad/Tool-X/blob/master/.sc/Tool-X.jpg"/>
</p>

<br/><br/><br/>

# How to use ?

- Type 0 : To install all tools.
- Type 1 : to sow all available tools and type the number of a tool which you want to install.
- Type 2 : if you want to update Tool-X.
- Type 3 : if you know About us.
- Type x : for exit.

<br/>

# Tool-X is available for

* Android
* Ubuntu

<br/>

# Warning

## I am not expert so use this tool at your own risk.

<br/>

# How to Install in termux ?

Open the termux app and type following commands.

* `apt update`

* `pkg install git`

* `git clone https://github.com/Rajkumrdusad/Tool-X.git`

* `cd Tool-X`

* `chmod +x install.aex`

* `sh install.aex` if not work than type `./install.aex`

<br/>

## Now Tool-X is installed successfully. To run Tool-X Type Tool-X

Now type Tool-X from anywhare in your terminal to open Tool-X.

<br/><br/>

# How to Install in GNURoot Debian Terminal ?

Open the GNURoot Debian app and type following commands.

* `apt update`

* `apt install git`

* `cd && git clone https://github.com/Rajkumrdusad/Tool-X.git`

* `cd Tool-X`

* `chmod +x install.aex`

* `sh install.aex` if not work than type `./install.aex`

<br/>

## Now Tool-X is installed successfully. To run Tool-X Type Tool-X

Now type Tool-X from anywhare in your terminal to open Tool-X. But use this tool only for legal purpose.

<br/><br/>

# How to install in Ubuntu ?

* `sudo apt-get Update`

* `sudo apt-get install git`

* `sudo git clone https://github.com/Rajkumrdusad/Tool-X.git`

* `cd Tool-X`

* `chmod +x install.aex`

* `sudo sh install.aex` OR `./install.aex`

<br/>

## Now Tool-X is installed successfully. To run Tool-X Type Tool-X

Now type Tool-X from anywhare in your terminal to open Tool-X. But use this tool only for legal purpose.

<br/><br/>
