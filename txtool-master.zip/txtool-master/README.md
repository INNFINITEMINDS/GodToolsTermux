txtool is made to help you for easly pentesting in termux,  
build on termux and only available for termux.  

# installation steps  
$ git clone https://github.com/kuburan/txtool.git  
$ cd txtool  
$ apt install python2  
$ ./install.py  

Done. type txtool to launch this tool.  

# Contact  
kuburan000@protonmail.ch  
