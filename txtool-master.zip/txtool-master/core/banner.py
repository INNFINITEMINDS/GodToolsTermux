#!/data/data/com.termux/files/usr/bin/python2
# -*- coding: utf-8 -*-

from fungsi import warna

def banner():
    print(warna.hijau + """
  _____      _    ___   ___  _
 |_   _|_  _| |_ / _ \ / _ \| |
   | | \ \/ / __| | | | | | | | """ + warna.kuning + """
   | |  >  <| |_| |_| | |_| | |___
   |_| /_/\_\\\__|\___/ \___/|_____|
"""+ warna.tutup + """
  Author     : """ + warna.abuabu + """ Kuburan A.K.A Gembur Ae """+ warna.tutup + """
  Version    : """ + warna.abuabu + """ 1.0 """+ warna.tutup + """
  Codename   : """ + warna.abuabu + """ Batu Nisan """+ warna.tutup + """
""" + warna.merah + """
========================================
========================================""" + warna.tutup + """
""")
